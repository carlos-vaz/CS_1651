/* 
 * PetLab logging utility functions
 * (c) Jack lange, 2015
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>


FILE * pet_log_stream = NULL;


